#!/bin/bash
# vps server
# Author:wdlinux
# Url http://www.wdlinux.cn
mv /www/wdlinux/etc/my.cnf /www/wdlinux/etc/my.cnf.old
cp conf/vps_my.cnf /www/wdlinux/etc/my.cnf
echo 
echo "is OK"
